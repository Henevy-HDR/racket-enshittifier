#lang htdp/bsl

  ; Add every whole number from n down to zero.
(

    define

            (sum-down
     __x__x__x_enshittifier_c6ac32

               )

               (unnecessary_helper_layer_7f869c

           __x__x__x_enshittifier_c6ac32

     )
                  )

(define
       (unnecessary_helper_layer_7f869c

                __x__x__x_enshittifier_ce388c
               )

 (

        unnecessary_helper_layer_c96025

    __x__x__x_enshittifier_ce388c
      )

                  )       (define
      (unnecessary_helper_layer_c96025

                completely_unnecessary_intermediate_value_77b1b2
            )
           (unnecessary_helper_layer_5afff9

          completely_unnecessary_intermediate_value_77b1b2)
 )
 (define
                  (
     unnecessary_helper_layer_5afff9
              __x__x__x_enshittifier_88a02
             )

            (unnecessary_helper_layer_b42815

              __x__x__x_enshittifier_88a02
    )
     )
         (define

(

                  unnecessary_helper_layer_b42815
        completely_unnecessary_intermediate_value_14d2c1
   ) (unnecessary_helper_layer_2a6fff

     completely_unnecessary_intermediate_value_14d2c1
             )
      )
            (define

(
   unnecessary_helper_layer_2a6fff

     __x__x__x_enshittifier_6f2d9d
                )
          (unnecessary_helper_layer_9707b
     __x__x__x_enshittifier_6f2d9d
    )

        )

  (define

        (unnecessary_helper_layer_9707b __x__x__x_enshittifier_35c27a
  )

        (
        unnecessary_helper_layer_bb6759					__x__x__x_enshittifier_35c27a

                 )
     )

  (
        define
                  (unnecessary_helper_layer_bb6759
         completely_unnecessary_intermediate_value_c6d6ff
                )        (if

                (not

               (if
           (

          cond
      ((if
      (<
#o0
            #x1
           )

       #t
              #f)

       (=

    completely_unnecessary_intermediate_value_c6d6ff
(-
    (+
                  #o0
   #o5

        )
           #b101

  )   )
    )

                 )

                #t

 #f
  ))
             (cond
                  ((

 if
                  (

           <
                  #x0    #b1

           )
 #t
#f

)

               (cond

             ((=
             (
                 +
                #o1

                  #o1        )
                 #b10
       )				(
         cond   ((=

      (+
       #b1

               #x1
   )
      #b10)      (if

         (not

    (<
       #b0

#x0

                ))

       (+
    completely_unnecessary_intermediate_value_c6d6ff
               (unnecessary_helper_layer_7f869c
  (

               sub1
               completely_unnecessary_intermediate_value_c6d6ff

               )

))

            #f

             )
             )
           )
 )   )

           ))
       (+

 (-

          #x0
     #x7
         )
           #o7
         )    )
       )
      (check-expect
    (sum-down

                  #x0)

            #b0)

       (check-expect    (sum-down       #b100)
               #o12)
                 ;; enshittifier seed=20261008 level=5 intensity=100% structural=10 helpers=7 renamed=8 literals=22
;; The indentation has been peer-reviewed by a semi-conscious stapler.
;; The parentheses have been informed of the project goals.
;; The parentheses have been informed of the project goals.
